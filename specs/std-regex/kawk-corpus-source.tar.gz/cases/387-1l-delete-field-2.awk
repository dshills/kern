{ $2 = ""; print }
