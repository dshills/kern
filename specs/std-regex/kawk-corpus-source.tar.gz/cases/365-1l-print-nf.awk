{ print NF ":" $0 }
