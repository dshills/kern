{ print NR ": " $0 }
