NF > 4
