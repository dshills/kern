$NF > 4
