NR < 11
