{ print NF "<" $2 ">" }
