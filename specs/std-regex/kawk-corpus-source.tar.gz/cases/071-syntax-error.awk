BEGIN { print "before" ; x = ; }
