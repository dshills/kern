BEGIN { print 1 == 1 }
