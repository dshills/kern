/name:bob/ { getline; print }
