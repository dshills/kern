length < 4
