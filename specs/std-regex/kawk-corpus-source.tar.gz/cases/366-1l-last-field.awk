{ print $NF }
