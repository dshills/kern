{ print $1 }
